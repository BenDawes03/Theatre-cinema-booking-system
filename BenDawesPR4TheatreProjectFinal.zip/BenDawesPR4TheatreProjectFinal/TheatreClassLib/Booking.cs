﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TheatreClassLib
{
    public class Booking
    {
        public Booking(int bookingID, Performance performance)
        {
            TotalTickets = 0;
            this.performance = performance;
            BookingID = bookingID;
            TotalPrice = 0;
            TicketList = new List<Ticket>();
        }

        public Booking(Performance performance)
        {
            this.TicketList = TicketList;
            this.performance = performance;
            TotalTickets = 0;
            TotalPrice = 0;
            TicketList = new List<Ticket>();
        }


        /// <summary>
        /// adds new ticket to list
        /// </summary>
        public void AddTicket(Ticket ticket)
        {
            TicketList.Add(ticket);
            TotalPrice += ticket.PricePaid;
            TotalTickets++;
        }
        /// <summary>
        /// removes ticket from list
        /// </summary>
        public void Removeticket()
        { }
        /// <summary>
        /// calculates total price of current booking
        /// </summary>
        public void RemoveDB()
        {
            
            SqlParameter BookingIDParam = new SqlParameter("@BookingID", BookingID);
            using (SqlConnection PubConn = new SqlConnection(connectionString))
            {
                using (SqlCommand bookingRemoveCommand = new SqlCommand("DELETE FROM Bookings WHERE BookingID = @BookingID", PubConn))
                {
                    PubConn.Open();

                    bookingRemoveCommand.Parameters.Add(BookingIDParam);

                    bookingRemoveCommand.ExecuteScalar();

                    bookingRemoveCommand.Parameters.Clear();

                    PubConn.Close();
                }
                
            }
            foreach (Ticket ticket in TicketList)
            {
                performance.SeatingArray[ticket.Seat.SeatNumber / 18, ticket.Seat.SeatNumber % 18].UnBook();
                ticket.removeDB();
            }
        }
    
        public void calculatePrice()
        { }
        /// <summary>
        /// saves the booking information in the database
        /// </summary>
        public void SaveNewDB()
        {
            foreach (Ticket ticket in TicketList)
            {
                ticket.SaveDB();
                ticket.Seat.Book();

            }
            SqlParameter TicketIDParam = new SqlParameter("@TicketID", TicketList[0].TicketID);
            SqlParameter BookingIDParam = new SqlParameter("@BookingID", BookingID);
            SqlParameter PerformanceParam = new SqlParameter("@PerformanceNumber", performance.PerformanceNumber);
            
            using (SqlConnection PubConn = new SqlConnection(connectionString))
            {
                using (SqlCommand bookingSaveCommand = new SqlCommand("INSERT INTO Bookings OUTPUT INSERTED.BookingID VALUES(@TicketID, @PerformanceNumber)", PubConn))
                {
                    PubConn.Open();
                    bookingSaveCommand.Parameters.Add(TicketIDParam);
                    bookingSaveCommand.Parameters.Add(BookingIDParam);
                    bookingSaveCommand.Parameters.Add(PerformanceParam);
                    BookingIDParam.Value = (int)bookingSaveCommand.ExecuteScalar();
                    
                    bookingSaveCommand.Parameters.Clear();
                    
                    PubConn.Close();
                }
                foreach(Ticket ticket in TicketList)
                {
                    TicketIDParam.Value =  ticket.TicketID;
                    if (ticket != TicketList[0])
                    {
                        using (SqlCommand bookingSaveCommand = new SqlCommand("SET IDENTITY_INSERT Bookings ON; INSERT INTO Bookings(BookingID, TicketID, PerformanceNumber) VALUES(@BookingID, @TicketID, @PerformanceNumber)", PubConn))
                        {
                            PubConn.Open();
                            bookingSaveCommand.Parameters.Add(TicketIDParam);
                            bookingSaveCommand.Parameters.Add(BookingIDParam);
                            bookingSaveCommand.Parameters.Add(PerformanceParam);
                            bookingSaveCommand.ExecuteScalar();
                            bookingSaveCommand.Parameters.Clear();

                            PubConn.Close();
                        }
                    }
                }
            }
        }



        private string connectionString = ConfigurationManager.ConnectionStrings["Conn"].ConnectionString;
        public List<Ticket> TicketList { get; private set; }
        private bool isValid;
        public Performance performance { get; private set; }
        public int BookingID { get; private set; }
     
        public int TotalTickets { get; private set; }
        public Double TotalPrice { get; private set; }
        

    }
}
