﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TheatreClassLib
{
    public class Ticket
    {
        /// <summary>
        /// removes the ticket from the database
        /// </summary>
        public void removeDB()
        {
            SqlParameter TicketIDParam = new SqlParameter("@TicketID", TicketID);
            using (SqlConnection PubConn = new SqlConnection(connectionString))
            {
                using (SqlCommand ticketRemoveCommand = new SqlCommand("DELETE FROM Tickets WHERE TicketID = @TicketID", PubConn))
                {
                    PubConn.Open();

                    ticketRemoveCommand.Parameters.Add(TicketIDParam);

                    ticketRemoveCommand.ExecuteScalar();

                    ticketRemoveCommand.Parameters.Clear();

                    PubConn.Close();
                }

            }
        }
        /// <summary>
        /// creates new ticket from database or booking 
        /// </summary>
        
        public Ticket(int ticketID, Customer customer, Seat seat, double pricePaid, string ticketType)
        {
            this.Seat = seat;
            this.TicketID = ticketID;
            Customer = customer;
            this.PricePaid = pricePaid;
            this.ticketType = ticketType;
        }
        public Ticket( Customer customer, Seat seat, double pricePaid, string ticketType)
        {
            this.Seat = seat;

            Customer = customer;
            this.PricePaid = pricePaid;
            this.ticketType = ticketType;
        }
        /// <summary>
        /// saves ticket info in database
        /// </summary>
        public void SaveDB()
        {
            SqlParameter CustomerParam = new SqlParameter("@CustomerID", Customer.CustomerID);
            SqlParameter SeatNumberParam = new SqlParameter("@SeatNumber", Seat.SeatNumber);
            SqlParameter TicketTypeParam = new SqlParameter("@TicketType", ticketType);
            SqlParameter PricePaidParam = new SqlParameter("@PricePaid", PricePaid);
            using (SqlConnection PubConn = new SqlConnection(connectionString))
            {
                using (SqlCommand ticketSaveCommand = new SqlCommand("INSERT INTO Tickets OUTPUT INSERTED.TicketID VALUES(@CustomerID, @SeatNumber, @TicketType, @PricePaid)", PubConn))
                {
                    PubConn.Open();
                    ticketSaveCommand.Parameters.Add(CustomerParam);
                    ticketSaveCommand.Parameters.Add(SeatNumberParam);
                    ticketSaveCommand.Parameters.Add(TicketTypeParam);
                    ticketSaveCommand.Parameters.Add(PricePaidParam);

                    TicketID = (int)ticketSaveCommand.ExecuteScalar();
                    PubConn.Close();
                }
            }
        }
        public void UpdateDB()
        {
            SqlParameter IDParam = new SqlParameter("@ID", TicketID);
            SqlParameter CustomerParam = new SqlParameter("@CustomerID", Customer.CustomerID);
            SqlParameter SeatNumberParam = new SqlParameter("@SeatNumber", Seat.SeatNumber);
            SqlParameter TicketTypeParam = new SqlParameter("@TicketType", ticketType);
            SqlParameter PricePaidParam = new SqlParameter("@PricePaid", PricePaid);
            using (SqlConnection PubConn = new SqlConnection(connectionString))
            {
                using (SqlCommand ticketUpdateCommand = new SqlCommand("UPDATE Tickets SET CustomerID = @CustomerID, SeatNumber = @SeatNumber, CustomerType = @TicketType, PricePaid = @PricePaid WHERE TicketID = @ID; ", PubConn))

                {
                    PubConn.Open();
                    ticketUpdateCommand.Parameters.Add(CustomerParam);
                    ticketUpdateCommand.Parameters.Add(SeatNumberParam);
                    ticketUpdateCommand.Parameters.Add(TicketTypeParam);
                    ticketUpdateCommand.Parameters.Add(PricePaidParam);
                    ticketUpdateCommand.Parameters.Add(IDParam);
                    ticketUpdateCommand.ExecuteScalar();
                    PubConn.Close();
                }
            }
        }

        public Customer Customer { get; private set; }
        private Performance performance;
        public Double PricePaid { get; private set; }
        public Seat Seat { get; private set; }
        public string ticketType { get; private set; }
        public int TicketID { get; private set; }
        private string connectionString = ConfigurationManager.ConnectionStrings["Conn"].ConnectionString;
    }
}
