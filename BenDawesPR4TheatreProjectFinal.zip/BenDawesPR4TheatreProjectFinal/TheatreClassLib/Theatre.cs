﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TheatreClassLib
{
    public class Theatre
    {
        
        public Theatre()
        {
            performanceList = new List<Performance>();
            CustomerList = new List<Customer>();
            
        }
        /// <summary>
        /// returns the performance list
        /// </summary>
        public List<Performance> GetPerformances()
        {
            return performanceList;
        }
        /// <summary>
        /// adds the performance to the list and DB
        /// </summary>
        public void Addperformance(int performanceNumber, string performanceTitle, DateTime peformanceDate)
        {
            performanceList.Add(new Performance(performanceNumber, performanceTitle, peformanceDate));
        }
        public void ClearPerformances()
        {
            performanceList.Clear();
        }

        /// <summary>
        /// Deletes the performance from the DB and List
        /// </summary>

        public void DeletePerformance(Performance performance)
        {
            
        }
        /// <summary>
        /// Edits the performance and updates DB
        /// </summary>

        public void EditPerformance(Performance performance)
        {

        }
       

        /// <summary>
        /// searches for the customer in the customer list
        /// </summary>
        /// <returns>customer searched for</returns>
        //public Customer SearchForCustomer(string name, string phone)
        //{

        //}
        private List<Performance> performanceList;
        public List<Customer> CustomerList { get; private set; }

        public List<Ticket> TicketList { get; private set; }
        


    }
}
