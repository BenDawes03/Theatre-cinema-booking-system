﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TheatreClassLib
{
    public class Performance
    {
        private string connectionString = ConfigurationManager.ConnectionStrings["Conn"].ConnectionString;
        public Performance(string performanceTitle, DateTime performanceDate)
        {
            this.PerformanceTitle = performanceTitle;
            this.PerformanceDate = performanceDate;
            BlockedSeats = new List<Seat>();
            
        }
        public Performance(int performanceNumber, string performanceTitle, DateTime performanceDate)
        {
            this.PerformanceTitle = performanceTitle;
            this.PerformanceDate = performanceDate;
            this.PerformanceNumber = performanceNumber;
            SeatingArray = new Seat[11, 18];
            BookingList = new List<Booking>();
            BlockedSeats = new List<Seat>();
        }
        /// <summary>
        /// crrates new booking instance and adds the details to DB
        /// </summary>
        
        /// <summary>
        /// edtis the booking details for the performance
        /// </summary>
        public void SaveDB()
        {
            SqlParameter PerformanceDateParam = new SqlParameter("@PerformanceDate", PerformanceDate);
            SqlParameter PerformanceTitleParam = new SqlParameter("@PerformanceTitle", PerformanceTitle);
            using (SqlConnection PubConn = new SqlConnection(connectionString))
            {
                using (SqlCommand PerformanceSaveCommand = new SqlCommand("INSERT INTO Performances OUTPUT INSERTED.PerformanceNumber VALUES(@PerformanceTitle, @PerformanceDate)", PubConn))
                {
                    PubConn.Open();
                    PerformanceSaveCommand.Parameters.Add(PerformanceDateParam);
                    PerformanceSaveCommand.Parameters.Add(PerformanceTitleParam);
                    
                    PerformanceNumber = (int)PerformanceSaveCommand.ExecuteScalar();
                    PerformanceSaveCommand.Parameters.Remove(PerformanceDateParam);
                    PerformanceSaveCommand.Parameters.Remove(PerformanceTitleParam);
                    PubConn.Close();
                }
            }
        }
        /// <summary>
        /// Displays the list of seating and who has booked which seat
        /// </summary>

        //public string DisplayTickets()
        //{ }

        /// <summary>
        /// deletes the performance from database
        /// </summary>
        public void DeleteData()
        { }
        /// <summary>
        /// edits the performance details in the database
        /// </summary>
        public void EditDetails(string newTitle, DateTime newDate)
        {
            this.PerformanceTitle = newTitle;
            PerformanceDate = newDate;
            SqlParameter PerformanceDateParam = new SqlParameter("@PerformanceDate", PerformanceDate);
            SqlParameter PerformanceTitleParam = new SqlParameter("@PerformanceTitle", PerformanceTitle);
            SqlParameter PerformanceNumberParam = new SqlParameter("@PerformanceNumber", PerformanceNumber);
            using (SqlConnection PubConn = new SqlConnection(connectionString))
            {
                using (SqlCommand PerformanceSaveCommand = new SqlCommand("UPDATE Performances SET PerformanceDate = @PerformanceDate, PerformanceTitle = @PerformanceTitle WHERE PerformanceNumber = @PerformanceNumber", PubConn))
                {
                    PubConn.Open();
                    PerformanceSaveCommand.Parameters.Add(PerformanceNumberParam);
                    PerformanceSaveCommand.Parameters.Add(PerformanceDateParam);
                    PerformanceSaveCommand.Parameters.Add(PerformanceTitleParam);

                    PerformanceSaveCommand.ExecuteScalar();
                    PubConn.Close();
                }
            }
        }
        public string PerformanceTitle { get; private set; }
        
        public int PerformanceNumber { get; private set; }
        public Seat[,] SeatingArray { get; private set; }
        public DateTime PerformanceDate { get; private set; }
        public List<Seat> BlockedSeats { get; private set; }
        public List<Booking> BookingList { get; private set; }

        public double TotalRevenue { get; private set; }
        public void AddRevenue(double price)
        {
            TotalRevenue += price;
        }
        public void RemoveDB()
        {
            SqlParameter PerformanceNumberParam = new SqlParameter("@PerformanceNumber", PerformanceNumber);
            using (SqlConnection PubConn = new SqlConnection(connectionString))
            {
                using (SqlCommand performanceRemoveCommand = new SqlCommand("DELETE FROM Performances WHERE PerformanceNumber = @PerformanceNumber", PubConn))
                {
                    PubConn.Open();

                    performanceRemoveCommand.Parameters.Add(PerformanceNumberParam);

                    performanceRemoveCommand.ExecuteScalar();

                    performanceRemoveCommand.Parameters.Clear();

                    PubConn.Close();
                }
                using (SqlCommand performanceRemoveCommand = new SqlCommand("DELETE FROM Blockings WHERE PerformanceNumber = @PerformanceNumber", PubConn))
                {
                    PubConn.Open();

                    performanceRemoveCommand.Parameters.Add(PerformanceNumberParam);

                    performanceRemoveCommand.ExecuteScalar();

                    performanceRemoveCommand.Parameters.Clear();

                    PubConn.Close();
                }
            }
        }
    }
}
