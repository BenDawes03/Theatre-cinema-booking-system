﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TheatreClassLib
{
    public class Customer
    {
        /// <summary>
        /// Customer inputed by the user
        /// </summary>

       
        
        public Customer(int customerID, string forename, string surname, string phoneNumber, int age)
        {
            this.Age = age;
            this.Surname = surname;
            this.CustomerID = customerID;
            this.Forename = forename;
            this.PhoneNumber = phoneNumber;
        }
        
        /// <summary>
        /// saves the customer to the database if they are new
        /// </summary>
        public void AddDataDB()
        { }
        /// <summary>
        /// Deletes the customer from the database
        /// </summary>
        public void DeleteFromDB()
        { }
        /// <summary>
        /// updates the customer's details in the database
        /// </summary>
        public void EditDB()
        { }

        public int Age { get; private set; }
        public string Forename { get; private set; }
        public string Surname { get; private set; }
        public string PhoneNumber { get; private set; }
        public int CustomerID { get; private set; }
        

    }
}
