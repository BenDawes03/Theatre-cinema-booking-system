﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TheatreClassLib
{
    public class Seat
    {
        public int SeatNumber { get; private set; }
        private int seatNumber;
        private string connectionString = ConfigurationManager.ConnectionStrings["Conn"].ConnectionString;
        public bool IsBooked { get; private set; }
        public bool IsBlocked { get; private set; }

        /// <summary>
        /// returns the ticket booked for the seat
        /// </summary>


        /// <summary>
        /// takes the data from database
        /// </summary>

        public Seat(int seatNumber)
        {
            this.SeatNumber = seatNumber;
            IsBooked = false;
            IsBlocked = false;
        }
        /// <summary>
        /// creates a dummy ticket for the seat with name customerType block
        /// </summary>
        /// <param name="performance"></param>
        public void Block(int performanceNumber)
        {
            IsBlocked = true;

            SqlParameter SeatNumberParam = new SqlParameter("@SeatNumber", SeatNumber);
            SqlParameter PerformanceNumberParam = new SqlParameter("@PerformanceNumber", performanceNumber);
            using (SqlConnection PubConn = new SqlConnection(connectionString))
            {
                using (SqlCommand blockSaveCommand = new SqlCommand("INSERT INTO Blockings VALUES(@SeatNumber, @performanceNumber)", PubConn))
                {
                    PubConn.Open();
                    blockSaveCommand.Parameters.Add(PerformanceNumberParam);
                    blockSaveCommand.Parameters.Add(SeatNumberParam);
                    

                    blockSaveCommand.ExecuteScalar();
                    blockSaveCommand.Parameters.Clear();
                    PubConn.Close();
                }
            }

        }
        /// <summary>
        /// deletes the ticket associated if it is Customer type block otherwise returns error
        /// </summary>
        /// <param name="performance"></param>
        public void UnBlock(int performanceNumber)
        {
            IsBlocked = false;
            
            SqlParameter SeatNumberParam = new SqlParameter("@SeatNumber", SeatNumber);
            SqlParameter PerformanceNumberParam = new SqlParameter("@PerformanceNumber", performanceNumber);
            using (SqlConnection PubConn = new SqlConnection(connectionString))
            {
                using (SqlCommand blockSaveCommand = new SqlCommand("DELETE FROM Blockings WHERE SeatNumber = @SeatNumber AND PerformanceNumber = @performanceNumber", PubConn))
                {
                    PubConn.Open();
                    blockSaveCommand.Parameters.Add(PerformanceNumberParam);
                    blockSaveCommand.Parameters.Add(SeatNumberParam);


                    blockSaveCommand.ExecuteScalar();
                    blockSaveCommand.Parameters.Clear();
                    PubConn.Close();
                }
            }
        }
        public void Block()
        {
            IsBlocked = true;
        }
        /// <summary>
        /// adds the ticket to the DB
        /// </summary>
        /// <param name="performance"></param>
        public void Book()
        {
            IsBooked = true;
        }
        /// <summary>
        /// returns if the seat has a ticket associated with it
        /// </summary>
       
        public void UnBook()
        {
            IsBooked = false;
        }
  
        
        
 

    }
}
