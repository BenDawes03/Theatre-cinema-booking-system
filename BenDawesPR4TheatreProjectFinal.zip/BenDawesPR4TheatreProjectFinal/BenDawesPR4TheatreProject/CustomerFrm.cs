﻿
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TheatreClassLib;


namespace BenDawesPR4TheatreProject
{
    public partial class CustomerFrm : Form
    {
        private List<Customer> customerList;
        private string connectionString = ConfigurationManager.ConnectionStrings["Conn"].ConnectionString;
        public CustomerFrm()
        {
            InitializeComponent();
            this.customerList = new List<Customer>();
            DisplayCustomers();
        }
        private void DisplayCustomers()
        {
            List<string> surnameList = new List<string>();
            using (SqlConnection PubConn = new SqlConnection(connectionString))
            {
               
                using (SqlCommand customerReaderCommand = new SqlCommand("SELECT * FROM Customers", PubConn))
                {
                    PubConn.Open();

                    SqlDataReader customerReader = customerReaderCommand.ExecuteReader();

                    while (customerReader.Read())
                    {
                        bool customerExists = false;
                        foreach (Customer c in customerList)
                        {
                            if (c.CustomerID == (int)customerReader[0])
                            {
                                customerExists = true;
                            }
                        }
                        if (!customerExists)
                        {
                            customerList.Add(new Customer((int)customerReader[0], (string)customerReader[1], (string)customerReader[2], (string)customerReader[3], (int)customerReader[4]));
                            surnameList.Add((string)customerReader[2]);
                        }
                    }
                    PubConn.Close();
                }
            }

            surnameList.Sort();
            DataTable customerTable = new DataTable();
            customerTable.Columns.Add("Customer", typeof(Customer));
            customerTable.Columns.Add("Name", typeof(string));
            customerTable.Columns.Add("Phone Number", typeof(string));
            
            foreach(string surname in surnameList)
            {
                foreach (Customer customer in customerList)
                {
                    if (customer.Surname == surname)
                    {
                        customerTable.Rows.Add(customer, $"{customer.Forename} {customer.Surname}", customer.PhoneNumber);
                    }
                }
            }
            
            CustomerGridView.DataSource = customerTable;
            CustomerGridView.Columns[0].Visible = false;
           
        }
        
        private void ViewBookings_Click(object sender, EventArgs e)
        {
            if(CustomerGridView.SelectedRows.Count > 0)
            {
                Customer selectedCustomer = (Customer)CustomerGridView.SelectedRows[0].Cells[0].Value;
                customerBookingsFrm newForm = new customerBookingsFrm(selectedCustomer);
                newForm.ShowDialog();
            }
        }

        private void SearchButton_Click(object sender, EventArgs e)
        {
            
            string searchText = SearchBox.Text;
            DataTable customerTable = new DataTable();
            customerTable.Columns.Add("Name", typeof(string));
            customerTable.Columns.Add("Phone Number", typeof(string));
            foreach (Customer customer in customerList)
            {
                if (customer.PhoneNumber == searchText)
                {
                    customerTable.Rows.Add(customer.Forename + customer.Surname, customer.PhoneNumber);
                }
            }
            CustomerGridView.DataSource = customerTable;
        }

        private void CancelButton_Click(object sender, EventArgs e)
        {
            DisplayCustomers();
        }

        private void AddCustomerButton_Click(object sender, EventArgs e)
        {
            AddCustomerFrm newCustomerFrm = new AddCustomerFrm();
            newCustomerFrm.ShowDialog();
            DisplayCustomers();
        }

       
    }
}
