﻿
namespace BenDawesPR4TheatreProject
{
    partial class BookingForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.customerGridView = new System.Windows.Forms.DataGridView();
            this.SeatGridView = new System.Windows.Forms.DataGridView();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.AddCustomerButton = new System.Windows.Forms.Button();
            this.CancelButton = new System.Windows.Forms.Button();
            this.BookButton = new System.Windows.Forms.Button();
            this.CalculatePriceButton = new System.Windows.Forms.Button();
            this.BookUnderCustomerButton = new System.Windows.Forms.Button();
            this.isGuestBox = new System.Windows.Forms.CheckBox();
            this.button3 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.customerGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SeatGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // customerGridView
            // 
            this.customerGridView.AllowUserToAddRows = false;
            this.customerGridView.AllowUserToDeleteRows = false;
            this.customerGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.customerGridView.Location = new System.Drawing.Point(473, 34);
            this.customerGridView.Name = "customerGridView";
            this.customerGridView.RowHeadersWidth = 62;
            this.customerGridView.RowTemplate.Height = 28;
            this.customerGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.customerGridView.Size = new System.Drawing.Size(526, 474);
            this.customerGridView.TabIndex = 0;
            this.customerGridView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.customerGridView_CellContentClick);
            // 
            // SeatGridView
            // 
            this.SeatGridView.AllowUserToAddRows = false;
            this.SeatGridView.AllowUserToDeleteRows = false;
            this.SeatGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.SeatGridView.Location = new System.Drawing.Point(12, 44);
            this.SeatGridView.Name = "SeatGridView";
            this.SeatGridView.RowHeadersWidth = 62;
            this.SeatGridView.RowTemplate.Height = 28;
            this.SeatGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.SeatGridView.Size = new System.Drawing.Size(240, 257);
            this.SeatGridView.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(469, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(133, 20);
            this.label2.TabIndex = 4;
            this.label2.Text = "List of Customers";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(148, 20);
            this.label1.TabIndex = 5;
            this.label1.Text = "Seats to be booked";
            // 
            // AddCustomerButton
            // 
            this.AddCustomerButton.Location = new System.Drawing.Point(708, 514);
            this.AddCustomerButton.Name = "AddCustomerButton";
            this.AddCustomerButton.Size = new System.Drawing.Size(161, 34);
            this.AddCustomerButton.TabIndex = 7;
            this.AddCustomerButton.Text = "Add new customer";
            this.AddCustomerButton.UseVisualStyleBackColor = true;
            this.AddCustomerButton.Click += new System.EventHandler(this.AddCustomer_Click);
            // 
            // CancelButton
            // 
            this.CancelButton.Location = new System.Drawing.Point(16, 514);
            this.CancelButton.Name = "CancelButton";
            this.CancelButton.Size = new System.Drawing.Size(76, 34);
            this.CancelButton.TabIndex = 14;
            this.CancelButton.Text = "Cancel";
            this.CancelButton.UseVisualStyleBackColor = true;
            this.CancelButton.Click += new System.EventHandler(this.CancelButton_Click);
            // 
            // BookButton
            // 
            this.BookButton.Location = new System.Drawing.Point(98, 514);
            this.BookButton.Name = "BookButton";
            this.BookButton.Size = new System.Drawing.Size(80, 34);
            this.BookButton.TabIndex = 15;
            this.BookButton.Text = "Book";
            this.BookButton.UseVisualStyleBackColor = true;
            this.BookButton.Click += new System.EventHandler(this.Book_Click);
            // 
            // CalculatePriceButton
            // 
            this.CalculatePriceButton.Location = new System.Drawing.Point(184, 514);
            this.CalculatePriceButton.Name = "CalculatePriceButton";
            this.CalculatePriceButton.Size = new System.Drawing.Size(161, 34);
            this.CalculatePriceButton.TabIndex = 16;
            this.CalculatePriceButton.Text = "Calculate price";
            this.CalculatePriceButton.UseVisualStyleBackColor = true;
            this.CalculatePriceButton.Click += new System.EventHandler(this.CalculatePriceButton_Click);
            // 
            // BookUnderCustomerButton
            // 
            this.BookUnderCustomerButton.Location = new System.Drawing.Point(473, 514);
            this.BookUnderCustomerButton.Name = "BookUnderCustomerButton";
            this.BookUnderCustomerButton.Size = new System.Drawing.Size(217, 34);
            this.BookUnderCustomerButton.TabIndex = 17;
            this.BookUnderCustomerButton.Text = "book seat under customer";
            this.BookUnderCustomerButton.UseVisualStyleBackColor = true;
            this.BookUnderCustomerButton.Click += new System.EventHandler(this.BookSeatUnderCustomer);
            // 
            // isGuestBox
            // 
            this.isGuestBox.AutoSize = true;
            this.isGuestBox.Location = new System.Drawing.Point(12, 367);
            this.isGuestBox.Name = "isGuestBox";
            this.isGuestBox.Size = new System.Drawing.Size(224, 24);
            this.isGuestBox.TabIndex = 18;
            this.isGuestBox.Text = "selected customer is guest";
            this.isGuestBox.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(12, 317);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(161, 34);
            this.button3.TabIndex = 19;
            this.button3.Text = "Select all seats";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.SelectAllSeats_Click);
            // 
            // BookingForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1011, 551);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.isGuestBox);
            this.Controls.Add(this.BookUnderCustomerButton);
            this.Controls.Add(this.CalculatePriceButton);
            this.Controls.Add(this.BookButton);
            this.Controls.Add(this.CancelButton);
            this.Controls.Add(this.AddCustomerButton);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.SeatGridView);
            this.Controls.Add(this.customerGridView);
            this.Name = "BookingForm";
            this.Text = "BookingForm";
            this.Load += new System.EventHandler(this.BookingForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.customerGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SeatGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView customerGridView;
        private System.Windows.Forms.DataGridView SeatGridView;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button AddCustomerButton;
        private System.Windows.Forms.Button CancelButton;
        private System.Windows.Forms.Button BookButton;
        private System.Windows.Forms.Button CalculatePriceButton;
        private System.Windows.Forms.Button BookUnderCustomerButton;
        private System.Windows.Forms.CheckBox isGuestBox;
        private System.Windows.Forms.Button button3;
    }
}