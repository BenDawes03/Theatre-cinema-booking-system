﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TheatreClassLib;

namespace BenDawesPR4TheatreProject
{
    public partial class TicketForm : Form
    {
        string outputText;
        Dictionary<int, Ticket> ticketDictionary;
        Performance performance;

        public TicketForm(Performance selectedPerformance)
        {
            InitializeComponent();
            performance = selectedPerformance;
            ticketDictionary = new Dictionary<int, Ticket>();
            foreach (Booking booking in performance.BookingList)
            {
                foreach(Ticket ticket in booking.TicketList)
                {
                    ticketDictionary.Add(ticket.Seat.SeatNumber, ticket);
                }
            }
            outputText = $"performance name: {performance.PerformanceTitle}  \r\nperformance date: {performance.PerformanceDate} \r\n seats free: {198 - (ticketDictionary.Values.Count + performance.BlockedSeats.Count)}  seats booked: {ticketDictionary.Count} seats blocked: {performance.BlockedSeats.Count}";
            for (int i = 1; i <= 11; i++)
            {
                for(int j = 1; j <= 18; j++)
                {
                    try
                    {
                        outputText += $"\r\n{(char)(65 + (i - 1))} {j}: Booked	{ticketDictionary[(((i - 1) * 18) + j)].Customer.Forename + ticketDictionary[(((i - 1) * 18) + j)].Customer.Surname} {ticketDictionary[(((i - 1) * 18) + j)].Customer.PhoneNumber}";
                    }
                    catch
                    {
                        if (performance.SeatingArray[i - 1, j - 1] == null)
                        {
                            outputText += $"\r\n{(char)(65 + (i - 1))} {j}: Free";
                        }
                        else
                        {

                            if (performance.SeatingArray[i - 1, j - 1].IsBlocked)
                            {
                                outputText += $"\r\n{(char)(65 + (i - 1))} {j}: Blocked";
                            }
                            else
                            {
                                outputText += $"\r\n{(char)(65 + (i - 1))} {j}: Free";
                            }
                        }
                    }
                    
                    
                }
            }
            OutputBox.Text = outputText;
        }

        private void OutputButton_Click(object sender, EventArgs e)
        {

            StreamWriter ticketWriter = File.CreateText(@".\Performance ticket information\" + performance.PerformanceTitle);
       
            ticketWriter.Write(outputText);
            ticketWriter.Dispose();
            
        }
    }
}
