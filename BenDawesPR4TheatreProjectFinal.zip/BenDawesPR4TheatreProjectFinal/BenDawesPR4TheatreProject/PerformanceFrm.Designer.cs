﻿
namespace BenDawesPR4TheatreProject
{
    partial class PerformanceFrm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.PerformanceGridView = new System.Windows.Forms.DataGridView();
            this.bookingGridView = new System.Windows.Forms.DataGridView();
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.AddPerformanceButton = new System.Windows.Forms.Button();
            this.EditPerformanceButton = new System.Windows.Forms.Button();
            this.EditBookingButton = new System.Windows.Forms.Button();
            this.DeleteBookingButton = new System.Windows.Forms.Button();
            this.DeletePerformanceButton = new System.Windows.Forms.Button();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.menuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addNewCustomerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bookSelectedSeatsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.editSelectedBookingToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.blockunblockSelectedSeatsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addNewCustomerToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.searchCustomersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewTicketListToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.BlockSeatButton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.PerformanceGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bookingGridView)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // PerformanceGridView
            // 
            this.PerformanceGridView.AllowUserToAddRows = false;
            this.PerformanceGridView.AllowUserToDeleteRows = false;
            this.PerformanceGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.PerformanceGridView.Location = new System.Drawing.Point(31, 71);
            this.PerformanceGridView.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.PerformanceGridView.MultiSelect = false;
            this.PerformanceGridView.Name = "PerformanceGridView";
            this.PerformanceGridView.ReadOnly = true;
            this.PerformanceGridView.RowHeadersWidth = 62;
            this.PerformanceGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.PerformanceGridView.Size = new System.Drawing.Size(427, 231);
            this.PerformanceGridView.TabIndex = 0;
            this.PerformanceGridView.RowEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.PerformanceGridView_RowEnter);
            // 
            // bookingGridView
            // 
            this.bookingGridView.AllowUserToAddRows = false;
            this.bookingGridView.AllowUserToDeleteRows = false;
            this.bookingGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.bookingGridView.Location = new System.Drawing.Point(675, 71);
            this.bookingGridView.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.bookingGridView.MultiSelect = false;
            this.bookingGridView.Name = "bookingGridView";
            this.bookingGridView.ReadOnly = true;
            this.bookingGridView.RowHeadersWidth = 62;
            this.bookingGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.bookingGridView.Size = new System.Drawing.Size(397, 231);
            this.bookingGridView.TabIndex = 2;
            this.bookingGridView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.BookingGridView_CellContentClick);
            this.bookingGridView.RowEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.bookingGridView_RowEnter);
            this.bookingGridView.RowHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.bookingGridView_RowHeaderMouseClick);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(567, 312);
            this.button1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(146, 35);
            this.button1.TabIndex = 3;
            this.button1.Text = "Add Booking";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.addBooking_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(671, 46);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(75, 20);
            this.label1.TabIndex = 4;
            this.label1.Text = "Bookings";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(27, 46);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(108, 20);
            this.label2.TabIndex = 5;
            this.label2.Text = "Performances";
            // 
            // AddPerformanceButton
            // 
            this.AddPerformanceButton.Location = new System.Drawing.Point(31, 312);
            this.AddPerformanceButton.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.AddPerformanceButton.Name = "AddPerformanceButton";
            this.AddPerformanceButton.Size = new System.Drawing.Size(146, 35);
            this.AddPerformanceButton.TabIndex = 6;
            this.AddPerformanceButton.Text = "Add Performance";
            this.AddPerformanceButton.UseVisualStyleBackColor = true;
            this.AddPerformanceButton.Click += new System.EventHandler(this.AddPerformanceButton_Click);
            // 
            // EditPerformanceButton
            // 
            this.EditPerformanceButton.Location = new System.Drawing.Point(186, 312);
            this.EditPerformanceButton.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.EditPerformanceButton.Name = "EditPerformanceButton";
            this.EditPerformanceButton.Size = new System.Drawing.Size(146, 35);
            this.EditPerformanceButton.TabIndex = 7;
            this.EditPerformanceButton.Text = "Edit Performance";
            this.EditPerformanceButton.UseVisualStyleBackColor = true;
            this.EditPerformanceButton.Click += new System.EventHandler(this.EditPerformanceButton_Click);
            // 
            // EditBookingButton
            // 
            this.EditBookingButton.Location = new System.Drawing.Point(721, 312);
            this.EditBookingButton.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.EditBookingButton.Name = "EditBookingButton";
            this.EditBookingButton.Size = new System.Drawing.Size(146, 35);
            this.EditBookingButton.TabIndex = 8;
            this.EditBookingButton.Text = "Edit Booking";
            this.EditBookingButton.UseVisualStyleBackColor = true;
            this.EditBookingButton.Click += new System.EventHandler(this.EditBooking_Click);
            // 
            // DeleteBookingButton
            // 
            this.DeleteBookingButton.Location = new System.Drawing.Point(875, 312);
            this.DeleteBookingButton.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.DeleteBookingButton.Name = "DeleteBookingButton";
            this.DeleteBookingButton.Size = new System.Drawing.Size(146, 35);
            this.DeleteBookingButton.TabIndex = 9;
            this.DeleteBookingButton.Text = "Delete booking";
            this.DeleteBookingButton.UseVisualStyleBackColor = true;
            this.DeleteBookingButton.Click += new System.EventHandler(this.DeleteBookingClick);
            // 
            // DeletePerformanceButton
            // 
            this.DeletePerformanceButton.Location = new System.Drawing.Point(340, 312);
            this.DeletePerformanceButton.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.DeletePerformanceButton.Name = "DeletePerformanceButton";
            this.DeletePerformanceButton.Size = new System.Drawing.Size(173, 35);
            this.DeletePerformanceButton.TabIndex = 10;
            this.DeletePerformanceButton.Text = "Delete Performance";
            this.DeletePerformanceButton.UseVisualStyleBackColor = true;
            this.DeletePerformanceButton.Click += new System.EventHandler(this.DeletePerformanceButton_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.GripMargin = new System.Windows.Forms.Padding(2, 2, 0, 2);
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1366, 33);
            this.menuStrip1.TabIndex = 11;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // menuToolStripMenuItem
            // 
            this.menuToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addNewCustomerToolStripMenuItem,
            this.addNewCustomerToolStripMenuItem1,
            this.searchCustomersToolStripMenuItem});
            this.menuToolStripMenuItem.Name = "menuToolStripMenuItem";
            this.menuToolStripMenuItem.Size = new System.Drawing.Size(73, 29);
            this.menuToolStripMenuItem.Text = "Menu";
            // 
            // addNewCustomerToolStripMenuItem
            // 
            this.addNewCustomerToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bookSelectedSeatsToolStripMenuItem,
            this.editSelectedBookingToolStripMenuItem,
            this.blockunblockSelectedSeatsToolStripMenuItem,
            this.viewTicketListToolStripMenuItem});
            this.addNewCustomerToolStripMenuItem.Name = "addNewCustomerToolStripMenuItem";
            this.addNewCustomerToolStripMenuItem.Size = new System.Drawing.Size(286, 34);
            this.addNewCustomerToolStripMenuItem.Text = "Selected performance";
            // 
            // bookSelectedSeatsToolStripMenuItem
            // 
            this.bookSelectedSeatsToolStripMenuItem.Name = "bookSelectedSeatsToolStripMenuItem";
            this.bookSelectedSeatsToolStripMenuItem.Size = new System.Drawing.Size(341, 34);
            this.bookSelectedSeatsToolStripMenuItem.Text = "Book selected Seats";
            this.bookSelectedSeatsToolStripMenuItem.Click += new System.EventHandler(this.bookSelectedSeatsToolStripMenuItem_Click);
            // 
            // editSelectedBookingToolStripMenuItem
            // 
            this.editSelectedBookingToolStripMenuItem.Name = "editSelectedBookingToolStripMenuItem";
            this.editSelectedBookingToolStripMenuItem.Size = new System.Drawing.Size(341, 34);
            this.editSelectedBookingToolStripMenuItem.Text = "Edit Selected Booking";
            this.editSelectedBookingToolStripMenuItem.Click += new System.EventHandler(this.editSelectedBookingToolStripMenuItem_Click);
            // 
            // blockunblockSelectedSeatsToolStripMenuItem
            // 
            this.blockunblockSelectedSeatsToolStripMenuItem.Name = "blockunblockSelectedSeatsToolStripMenuItem";
            this.blockunblockSelectedSeatsToolStripMenuItem.Size = new System.Drawing.Size(341, 34);
            this.blockunblockSelectedSeatsToolStripMenuItem.Text = "block/unblock selected seats";
            this.blockunblockSelectedSeatsToolStripMenuItem.Click += new System.EventHandler(this.blockunblockSelectedSeatsToolStripMenuItem_Click);
            // 
            // addNewCustomerToolStripMenuItem1
            // 
            this.addNewCustomerToolStripMenuItem1.Name = "addNewCustomerToolStripMenuItem1";
            this.addNewCustomerToolStripMenuItem1.Size = new System.Drawing.Size(286, 34);
            this.addNewCustomerToolStripMenuItem1.Text = "Add new customer";
            this.addNewCustomerToolStripMenuItem1.Click += new System.EventHandler(this.addNewCustomerToolStripMenuItem1_Click);
            // 
            // searchCustomersToolStripMenuItem
            // 
            this.searchCustomersToolStripMenuItem.Name = "searchCustomersToolStripMenuItem";
            this.searchCustomersToolStripMenuItem.Size = new System.Drawing.Size(286, 34);
            this.searchCustomersToolStripMenuItem.Text = "View customers";
            this.searchCustomersToolStripMenuItem.Click += new System.EventHandler(this.searchCustomersToolStripMenuItem_Click);
            // 
            // viewTicketListToolStripMenuItem
            // 
            this.viewTicketListToolStripMenuItem.Name = "viewTicketListToolStripMenuItem";
            this.viewTicketListToolStripMenuItem.Size = new System.Drawing.Size(341, 34);
            this.viewTicketListToolStripMenuItem.Text = "View ticket list";
            this.viewTicketListToolStripMenuItem.Click += new System.EventHandler(this.viewTicketListToolStripMenuItem_Click);
            // 
            // BlockSeatButton
            // 
            this.BlockSeatButton.Location = new System.Drawing.Point(1029, 312);
            this.BlockSeatButton.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.BlockSeatButton.Name = "BlockSeatButton";
            this.BlockSeatButton.Size = new System.Drawing.Size(185, 35);
            this.BlockSeatButton.TabIndex = 12;
            this.BlockSeatButton.Text = "Block/unblock seats";
            this.BlockSeatButton.UseVisualStyleBackColor = true;
            this.BlockSeatButton.Click += new System.EventHandler(this.BlockSeatButton_Click);
            // 
            // PerformanceFrm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(1366, 1050);
            this.Controls.Add(this.BlockSeatButton);
            this.Controls.Add(this.DeletePerformanceButton);
            this.Controls.Add(this.DeleteBookingButton);
            this.Controls.Add(this.EditBookingButton);
            this.Controls.Add(this.EditPerformanceButton);
            this.Controls.Add(this.AddPerformanceButton);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.bookingGridView);
            this.Controls.Add(this.PerformanceGridView);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "PerformanceFrm";
            this.Text = "PerformanceFrm";
            ((System.ComponentModel.ISupportInitialize)(this.PerformanceGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bookingGridView)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView PerformanceGridView;
        private System.Windows.Forms.DataGridView bookingGridView;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button AddPerformanceButton;
        private System.Windows.Forms.Button EditPerformanceButton;
        private System.Windows.Forms.Button EditBookingButton;
        private System.Windows.Forms.Button DeleteBookingButton;
        private System.Windows.Forms.Button DeletePerformanceButton;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem menuToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addNewCustomerToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bookSelectedSeatsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem editSelectedBookingToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem blockunblockSelectedSeatsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem viewTicketListToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addNewCustomerToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem searchCustomersToolStripMenuItem;
        private System.Windows.Forms.Button BlockSeatButton;
    }
}