﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TheatreClassLib;

namespace BenDawesPR4TheatreProject
{
    public partial class PerformanceDetailsFrm : Form
    {
        
        string performanceTitle;
        DateTime performanceDate;
        Performance performance;
        bool isNew;
        
        public PerformanceDetailsFrm()
        {
            InitializeComponent();
            isNew = true;
            performanceDateTime.Format = DateTimePickerFormat.Time;
            
        }
        public PerformanceDetailsFrm(Performance selectedperformance)
        {
            InitializeComponent();
            performanceDateTime.Format = DateTimePickerFormat.Time;
            isNew = false;
            this.performance = selectedperformance;
            TitleBox.Text = performance.PerformanceTitle;
            performanceDateTime.Value = performance.PerformanceDate;
            
            
        }

        private void ConfirmButton_Click(object sender, EventArgs e)
        {
            if(isNew)
            {
                performanceTitle = TitleBox.Text;
                performanceDate = performanceDateTime.Value;
                Performance newPerfomance = new Performance(performanceTitle, performanceDate);
                newPerfomance.SaveDB();
                this.Close();
            }
            else
            {
                performanceTitle = TitleBox.Text;
                performanceDate = performanceDateTime.Value;
                
                performance.EditDetails(performanceTitle, performanceDate);
                this.Close();
            }
            
        }
    }
}
