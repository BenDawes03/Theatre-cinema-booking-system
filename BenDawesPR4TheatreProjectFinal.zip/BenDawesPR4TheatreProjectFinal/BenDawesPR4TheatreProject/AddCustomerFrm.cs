﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BenDawesPR4TheatreProject
{
    public partial class AddCustomerFrm : Form
    {
        private string connectionString = ConfigurationManager.ConnectionStrings["Conn"].ConnectionString;
        public AddCustomerFrm()
        {
            
            InitializeComponent();
        }
        
        private void CreateButton_Click(object sender, EventArgs e)
        {
            int age = 0;
            string phoneNumber = "";
            string forename  ="";
            string surname = "";
            bool nameValid = false;
            bool ageValid = false;
            bool phoneValid = false;
            if (ForenameBox.Text == null || SurnameBox.Text == null)
            {
                MessageBox.Show("Error, no name entered");
            }
            else
            {
                forename = ForenameBox.Text;
                surname = SurnameBox.Text;
                nameValid = true;
            }
            try
            {
                age = int.Parse(AgeBox.Text);
                ageValid = true;
            }
            catch
            {
                MessageBox.Show("Error age must contain numbers only");
            }
            try
            {
                
                phoneNumber = PhoneBox.Text;
                long test = long.Parse(phoneNumber);
                if (phoneNumber.Length == 11)
                {
                    phoneValid = true;
                }
                else
                {
                    MessageBox.Show("Error, the phone number entered was invalid");
                }
            }
            catch
            {
                MessageBox.Show("Error, phone number must contain numbers only");
            }
            if(nameValid && phoneValid && ageValid)
            {
                SqlParameter forenameParam = new SqlParameter("@Forename", forename);
                SqlParameter surnameParam = new SqlParameter("@Surname", surname);
                SqlParameter AgeParam = new SqlParameter("@Age", age);
                SqlParameter PhoneParam = new SqlParameter("@PhoneNumber", phoneNumber);
                using (SqlConnection PubConn = new SqlConnection(connectionString))
                {
                    using (SqlCommand customerAddCommand = new SqlCommand("INSERT INTO Customers VALUES (@Forename, @Surname, @PhoneNumber, @Age)", PubConn))
                    {
                        PubConn.Open();
                        customerAddCommand.Parameters.Add(AgeParam);
                        customerAddCommand.Parameters.Add(forenameParam);
                        customerAddCommand.Parameters.Add(surnameParam);
                        customerAddCommand.Parameters.Add(PhoneParam);
                        customerAddCommand.ExecuteScalar();
                        PubConn.Close();
                    }
                }
                
                this.Close();
            }
        }

        private void CancelButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
