﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TheatreClassLib;


namespace BenDawesPR4TheatreProject
{

    
    public partial class BookingForm : Form
    {
        List<Seat> seatsToBook;
        private string ConnectionString = ConfigurationManager.ConnectionStrings["Conn"].ConnectionString;
        private Booking newBooking;
        private bool isNew;
        private Performance performance;
        private Booking currentBooking;
       
        DataTable customerTable = new DataTable();
        
        public BookingForm(List<Seat> seatList, Performance performance)
        {
            this.performance = performance;
            isNew = true;
            newBooking = new Booking(performance);
            InitializeComponent();
            seatsToBook = seatList;
           
            customerTable.Columns.Add("Customer", typeof(Customer));
            customerTable.Columns.Add("Name", typeof(string));
            customerTable.Columns.Add("Phone number", typeof(string));
            customerTable.Columns.Add("Age", typeof(int));
            GetCustomers();
            customerGridView.DataSource = customerTable;
            customerGridView.Columns[0].Visible = false;
            

            DataTable seatTable = new DataTable();
            seatTable.Columns.Add("Seat", typeof(Seat));
            seatTable.Columns.Add("Seat name", typeof(string));
            seatTable.Columns.Add("booked", typeof(Ticket));
            int count = 0;
            foreach(Seat s in seatsToBook)
            {
                count++;
                seatTable.Rows.Add(s, $"{(char)(65 + (s.SeatNumber / 18))}  {(s.SeatNumber % 18) + 1}");

            }

            SeatGridView.DataSource = seatTable;
            SeatGridView.Columns[0].Visible = false;
            SeatGridView.Columns[2].Visible = false;

        }

        public BookingForm(Booking booking, List<Seat> newSeats, Performance performance)
        {
            
            currentBooking = booking;
            this.performance = performance;
            
            newBooking = new Booking(performance);
            InitializeComponent();
            seatsToBook = newSeats;

            customerTable.Columns.Add("Customer", typeof(Customer));
            customerTable.Columns.Add("Name", typeof(string));
            customerTable.Columns.Add("Phone number", typeof(string));
            customerTable.Columns.Add("Age", typeof(int));
            GetCustomers();
            customerGridView.DataSource = customerTable;
            customerGridView.Columns[0].Visible = false;


            DataTable seatTable = new DataTable();
            seatTable.Columns.Add("Seat", typeof(Seat));
            seatTable.Columns.Add("Seat name", typeof(string));
            seatTable.Columns.Add("booked", typeof(Ticket));
            int count = 0;
            foreach (Seat s in seatsToBook)
            {
                count++;
                seatTable.Rows.Add(s, $"{(char)(65 + (s.SeatNumber / 18))}  {(s.SeatNumber % 18) +1}");

            }

            SeatGridView.DataSource = seatTable;
            SeatGridView.Columns[0].Visible = false;
            SeatGridView.Columns[2].Visible = false;

        }


        private void GetCustomers()
        {
            customerTable.Rows.Clear();
            using (SqlConnection pubConn = new SqlConnection(ConnectionString))
            {
                using (SqlCommand customerCommand = new SqlCommand("SELECT * FROM Customers", pubConn))
                {
                    pubConn.Open();
                    SqlDataReader customerReader = customerCommand.ExecuteReader();

                    while (customerReader.Read())
                    {
                        customerTable.Rows.Add(new Customer((int)customerReader[0], (string)customerReader[1], (string)customerReader[2], (string)customerReader[3], (int)customerReader[4]), (string)customerReader[1] + (string)customerReader[2], (string)customerReader[3], (int)customerReader[4]);

                    }
                    pubConn.Close();
                }
            }
        }
        private void CancelButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void BookingForm_Load(object sender, EventArgs e)
        {

        }

        private void Book_Click(object sender, EventArgs e)
        {
            if(!isNew)
            {
                currentBooking.RemoveDB();
               
                
            }
            


            if (newBooking.TicketList.Count == seatsToBook.Count)
            {
                
                
                
                newBooking.SaveNewDB();
                this.Close();
                
               
            }
            else
            {
                MessageBox.Show("Error, not all seats have been booked under customers");
            }
            
            
        }

        private void BookSeatUnderCustomer(object sender, EventArgs e)
        {
            Customer selectedCustomer = (Customer)customerGridView.SelectedRows[0].Cells[0].Value;
            bool isBooked = false;
            foreach (DataGridViewRow row in SeatGridView.SelectedRows)
            {

                double multiplier = SmartPrice();
                Seat seatToBook = (Seat)row.Cells[0].Value;
                Ticket ticketToBook;
                
                foreach (Ticket ticket in newBooking.TicketList)
                {
                    
                    if (ticket.Seat.SeatNumber == seatToBook.SeatNumber)
                    {

                        isBooked = true;

                        
                    }
                    
                    

                }
                if (!isBooked)
                {


                    if (isGuestBox.Checked)
                    {
                        ticketToBook = new Ticket(selectedCustomer, seatToBook, 0, "Guest");

                    }
                    else
                    {
                        if (selectedCustomer.Age < 18 || selectedCustomer.Age >= 65)
                        {


                            ticketToBook = new Ticket(selectedCustomer, seatToBook,  multiplier * 5.00, "Child/Elder");

                        }
                        else
                        {
                            ticketToBook = new Ticket(selectedCustomer, seatToBook, multiplier * 10.00, "Adult");
                        }

                    }
                    newBooking.AddTicket(ticketToBook);
                    SeatGridView.SelectedRows[0].Cells[2].Value = ticketToBook;
                }
            }
            if(isBooked)
            {
                MessageBox.Show("you have already booked one of these seats under this customer, the remaining seats have been booked.");
            }
        }
        private double SmartPrice()
        {
            double multiplier = 1;
            TimeSpan difference = DateTime.Today.Subtract(performance.PerformanceDate);
            if(difference.TotalDays < 2)
            {
                multiplier = 0.5;
            }
            else if (performance.SeatingArray.Length < 10)
            {
                multiplier = 0.5;
            }
            return multiplier;
        }

        private void CalculatePriceButton_Click(object sender, EventArgs e)
        {
            MessageBox.Show($"the current price is £{newBooking.TotalPrice}");
        }

        private void SelectAllSeats_Click(object sender, EventArgs e)
        {
            SeatGridView.SelectAll();
        }

        private void customerGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void AddCustomer_Click(object sender, EventArgs e)
        {
            AddCustomerFrm newCustomerFrm = new AddCustomerFrm();
            
            newCustomerFrm.ShowDialog();
            GetCustomers();
        }

       
    }
}
