﻿
namespace BenDawesPR4TheatreProject
{
    partial class PerformanceDetailsFrm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.performanceDateTime = new System.Windows.Forms.DateTimePicker();
            this.TitleBox = new System.Windows.Forms.TextBox();
            this.PerformanceDateLabel = new System.Windows.Forms.Label();
            this.PerformanceTItleLabel = new System.Windows.Forms.Label();
            this.CancelButton = new System.Windows.Forms.Button();
            this.ConfirmButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // performanceDateTime
            // 
            this.performanceDateTime.Location = new System.Drawing.Point(12, 12);
            this.performanceDateTime.Name = "performanceDateTime";
            this.performanceDateTime.Size = new System.Drawing.Size(200, 26);
            this.performanceDateTime.TabIndex = 0;
            // 
            // TitleBox
            // 
            this.TitleBox.Location = new System.Drawing.Point(12, 115);
            this.TitleBox.Name = "TitleBox";
            this.TitleBox.Size = new System.Drawing.Size(200, 26);
            this.TitleBox.TabIndex = 1;
            // 
            // PerformanceDateLabel
            // 
            this.PerformanceDateLabel.AutoSize = true;
            this.PerformanceDateLabel.Location = new System.Drawing.Point(237, 17);
            this.PerformanceDateLabel.Name = "PerformanceDateLabel";
            this.PerformanceDateLabel.Size = new System.Drawing.Size(139, 20);
            this.PerformanceDateLabel.TabIndex = 2;
            this.PerformanceDateLabel.Text = "Performance Date";
            // 
            // PerformanceTItleLabel
            // 
            this.PerformanceTItleLabel.AutoSize = true;
            this.PerformanceTItleLabel.Location = new System.Drawing.Point(237, 118);
            this.PerformanceTItleLabel.Name = "PerformanceTItleLabel";
            this.PerformanceTItleLabel.Size = new System.Drawing.Size(135, 20);
            this.PerformanceTItleLabel.TabIndex = 3;
            this.PerformanceTItleLabel.Text = "Performance TItle";
            // 
            // CancelButton
            // 
            this.CancelButton.Location = new System.Drawing.Point(12, 218);
            this.CancelButton.Name = "CancelButton";
            this.CancelButton.Size = new System.Drawing.Size(72, 31);
            this.CancelButton.TabIndex = 4;
            this.CancelButton.Text = "Cancel";
            this.CancelButton.UseVisualStyleBackColor = true;
            // 
            // ConfirmButton
            // 
            this.ConfirmButton.Location = new System.Drawing.Point(90, 218);
            this.ConfirmButton.Name = "ConfirmButton";
            this.ConfirmButton.Size = new System.Drawing.Size(80, 31);
            this.ConfirmButton.TabIndex = 5;
            this.ConfirmButton.Text = "Confirm";
            this.ConfirmButton.UseVisualStyleBackColor = true;
            this.ConfirmButton.Click += new System.EventHandler(this.ConfirmButton_Click);
            // 
            // PerformanceDetailsFrm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(397, 261);
            this.Controls.Add(this.ConfirmButton);
            this.Controls.Add(this.CancelButton);
            this.Controls.Add(this.PerformanceTItleLabel);
            this.Controls.Add(this.PerformanceDateLabel);
            this.Controls.Add(this.TitleBox);
            this.Controls.Add(this.performanceDateTime);
            this.Name = "PerformanceDetailsFrm";
            this.Text = "Performance Details";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DateTimePicker performanceDateTime;
        private System.Windows.Forms.TextBox TitleBox;
        private System.Windows.Forms.Label PerformanceDateLabel;
        private System.Windows.Forms.Label PerformanceTItleLabel;
        private System.Windows.Forms.Button CancelButton;
        private System.Windows.Forms.Button ConfirmButton;
    }
}