﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TheatreClassLib;

namespace BenDawesPR4TheatreProject
{
    public partial class customerBookingsFrm : Form
    {
        Customer customer;
        private string connectionString = ConfigurationManager.ConnectionStrings["Conn"].ConnectionString;
        public customerBookingsFrm(Customer customer)
        {
            InitializeComponent();
            this.customer = customer;
            DataTable customerTable = new DataTable();
            customerTable.Columns.Add("Seat number", typeof(int));
            customerTable.Columns.Add("Performance Title", typeof(string));
            List<int> ticketIDList = new List<int>();
            
            Dictionary<int, int> ticketToSeatDictionary = new Dictionary<int, int>();
            Dictionary<int, int> ticketToPerformanceNumber = new Dictionary<int, int>();
            Dictionary<int, string> ticketToPerformanceName = new Dictionary<int, string>();

            using (SqlConnection PubConn = new SqlConnection(connectionString))
            {
                SqlParameter customerIDParam = new SqlParameter("@CustomerID", customer.CustomerID);
                using (SqlCommand customerReaderCommand = new SqlCommand("SELECT * FROM Tickets Where CustomerID = @CustomerID", PubConn))
                {
                    PubConn.Open();
                    customerReaderCommand.Parameters.Add(customerIDParam);
                    SqlDataReader ticketReader = customerReaderCommand.ExecuteReader();

                    while (ticketReader.Read())
                    {
                        ticketIDList.Add((int)ticketReader[0]);
                        ticketToSeatDictionary.Add((int)ticketReader[0], (int)ticketReader[2]);


                    }
                    PubConn.Close();
                }
                foreach (int ticketID in ticketIDList)
                {
                    int performanceNumber = 0;
                    SqlParameter ticketIDParam = new SqlParameter("@TicketID", ticketID);
                    using (SqlCommand performanceNumberCommand = new SqlCommand("SELECT PerformanceNumber FROM Bookings Where TicketID = @TicketID", PubConn))
                    {
                        performanceNumberCommand.Parameters.Add(ticketIDParam);
                        PubConn.Open();
                        performanceNumber = (int)performanceNumberCommand.ExecuteScalar();
                        ticketToPerformanceNumber.Add(ticketID, performanceNumber);
                        PubConn.Close();
                    }
                
                    
                    SqlParameter performanceNumberParam = new SqlParameter("@PerformanceNumber", performanceNumber);
                    using (SqlCommand performanceNumberCommand = new SqlCommand("SELECT PerformanceTitle FROM Performances Where PerformanceNumber = @PerformanceNumber", PubConn))
                    {
                        performanceNumberCommand.Parameters.Add(performanceNumberParam);
                        PubConn.Open();
                        string performanceTitle = (string)performanceNumberCommand.ExecuteScalar();
                        customerTable.Rows.Add(ticketToSeatDictionary[ticketID], performanceTitle);
                        PubConn.Close();
                    }
                }
            }
            CustomerTicketGridView.DataSource = customerTable;

        }
    }
}
