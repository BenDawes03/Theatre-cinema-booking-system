﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TheatreClassLib;

namespace BenDawesPR4TheatreProject
{
    public partial class LeaveSeatWarningFrm : Form
    {
        bool isNew;
        List<Seat> selectedSeats;
        Booking booking;
        Performance selectedPerformance;
        public LeaveSeatWarningFrm(List<Seat> selectedSeats, Booking booking, Performance selectedPerformance)
        {
            InitializeComponent();
            isNew = false;
            this.selectedPerformance = selectedPerformance;
            this.selectedSeats = selectedSeats;
            this.booking = booking;

        }
        public LeaveSeatWarningFrm(List<Seat> selectedSeats, Performance selectedPerformance)
        {
            InitializeComponent();
            isNew = true;
            this.selectedPerformance = selectedPerformance;
            this.selectedSeats = selectedSeats;
        }

        private void CancelButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void ContinueButton_Click(object sender, EventArgs e)
        {
            if (!isNew)
            {
                BookingForm edittedBookingFrm = new BookingForm(booking, selectedSeats, selectedPerformance);
                edittedBookingFrm.ShowDialog();
                this.Close();
            }
            else
            {
                BookingForm newBookingFrm = new BookingForm(selectedSeats, selectedPerformance);
                newBookingFrm.ShowDialog();
                this.Close();
            }
        }
    }
}
