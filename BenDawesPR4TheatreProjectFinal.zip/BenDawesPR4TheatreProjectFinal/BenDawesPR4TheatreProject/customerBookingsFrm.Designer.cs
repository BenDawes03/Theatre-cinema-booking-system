﻿
namespace BenDawesPR4TheatreProject
{
    partial class customerBookingsFrm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.CustomerTicketGridView = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.CustomerTicketGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // CustomerTicketGridView
            // 
            this.CustomerTicketGridView.AllowUserToAddRows = false;
            this.CustomerTicketGridView.AllowUserToDeleteRows = false;
            this.CustomerTicketGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.CustomerTicketGridView.Location = new System.Drawing.Point(12, 12);
            this.CustomerTicketGridView.MultiSelect = false;
            this.CustomerTicketGridView.Name = "CustomerTicketGridView";
            this.CustomerTicketGridView.ReadOnly = true;
            this.CustomerTicketGridView.RowHeadersWidth = 62;
            this.CustomerTicketGridView.RowTemplate.Height = 28;
            this.CustomerTicketGridView.Size = new System.Drawing.Size(399, 426);
            this.CustomerTicketGridView.TabIndex = 0;
            // 
            // customerBookingsFrm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(423, 449);
            this.Controls.Add(this.CustomerTicketGridView);
            this.Name = "customerBookingsFrm";
            this.Text = "Customer bookings ";
            ((System.ComponentModel.ISupportInitialize)(this.CustomerTicketGridView)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView CustomerTicketGridView;
    }
}