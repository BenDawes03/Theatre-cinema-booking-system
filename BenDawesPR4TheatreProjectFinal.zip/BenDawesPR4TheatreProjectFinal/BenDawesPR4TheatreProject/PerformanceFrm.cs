﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TheatreClassLib;


namespace BenDawesPR4TheatreProject
{
    public partial class PerformanceFrm : Form
    {

        Theatre theatre = new Theatre();
        private PictureBox[,] pictureBoxArray = new PictureBox[11, 18];
        private const string IMAGEPATH = @".\SeatImages\";
        private string connectionString = ConfigurationManager.ConnectionStrings["Conn"].ConnectionString;
        private const int MAXROWS = 11;
        private const int MAXCOLUMNS = 18;
        private const int startingButtonXPosition = 0;
        private const int startingButtonYPosition = 230;
        private List<Seat> selectedSeats;
        Performance selectedPerformance;
        private const int SEATSPACING = 7;
        private int userSelectedSeats = 0;
        public PerformanceFrm()
        {

            bool databaseExists = true;
            using (SqlConnection PubConn = new SqlConnection(connectionString))
            {
                try
                {
                    PubConn.Open();
                    PubConn.Close();
                }
                catch
                {
                    databaseExists = false;
                }
               
                
            }
            if (databaseExists)
            {
                InitializeComponent();
                //Generate the seats
                int buttonXposition = startingButtonXPosition;
                int buttonYPosition = startingButtonYPosition;

                for (int row = 0; row < MAXROWS; row++)
                {

                    for (int column = 0; column < MAXCOLUMNS; column++)
                    {


                        PictureBox seatPictureBox = new PictureBox();
                        seatPictureBox.Width = 40;
                        seatPictureBox.Height = 30;
                        seatPictureBox.Name = ((row * 18) + column).ToString();
                        seatPictureBox.Image = Image.FromFile(IMAGEPATH + "DefaultSeat" + ".jpg");
                        seatPictureBox.Click += new EventHandler(SeatSelected);
                        seatPictureBox.Tag = "";
                        seatPictureBox.SizeMode = PictureBoxSizeMode.StretchImage;
                        buttonXposition = startingButtonXPosition + column * (SEATSPACING + seatPictureBox.Width);
                        buttonYPosition = startingButtonYPosition + row * (SEATSPACING + seatPictureBox.Height);
                        seatPictureBox.Location = new Point(buttonXposition, buttonYPosition);
                        pictureBoxArray[row, column] = seatPictureBox;
                        Controls.Add(seatPictureBox);
                        ToolTip toolTip1 = new ToolTip();
                        toolTip1.SetToolTip(seatPictureBox, $"{(int.Parse(seatPictureBox.Name) / 18) + 1},{(int.Parse(seatPictureBox.Name) % 18) + 1}");



                    }
                }
                this.Width = startingButtonXPosition + (18 * (SEATSPACING + 40) + SEATSPACING);
                this.Height = startingButtonYPosition + (12 * (SEATSPACING + 30));
                GetPerformances();

                //load the customers

                using (SqlConnection PubConn = new SqlConnection(connectionString))
                {
                    using (SqlCommand customerReaderCommand = new SqlCommand("SELECT * FROM Customers", PubConn))
                    {
                        PubConn.Open();

                        SqlDataReader customerReader = customerReaderCommand.ExecuteReader();

                        while (customerReader.Read())
                        {
                            bool customerExists = false;
                            foreach (Customer c in theatre.CustomerList)
                            {
                                if (c.CustomerID == (int)customerReader[0])
                                {
                                    customerExists = true;
                                }
                            }
                            if (!customerExists)
                            {
                                theatre.CustomerList.Add(new Customer((int)customerReader[0], (string)customerReader[1], (string)customerReader[2], (string)customerReader[3], (int)customerReader[4]));

                            }
                        }
                        PubConn.Close();
                    }
                }

            }
            else
            {
                MessageBox.Show("Error Database not found");
                this.Close();
            }
        }
        
        private void GetPerformances()
        {
            //load the performances


            theatre.ClearPerformances();
            DataTable performanceTable = new DataTable();
            performanceTable.Columns.Add("Performance", typeof(Performance));
            performanceTable.Columns.Add("Performance title", typeof(string));
            performanceTable.Columns.Add("Performance date", typeof(DateTime));
           

            using (SqlConnection PubConn = new SqlConnection(connectionString))
            {
                using (SqlCommand performanceReaderCommand = new SqlCommand("Select * from Performances", PubConn))
                {
                    PubConn.Open();
                    SqlDataReader performanceReader = performanceReaderCommand.ExecuteReader();
                    if (!performanceReader.HasRows)
                    {
                        MessageBox.Show("No performances found please enter new performance data");
                        PerformanceDetailsFrm newPerformanceFrm = new PerformanceDetailsFrm();
                        newPerformanceFrm.ShowDialog();
                        GetPerformances();
                    }
                    
                    while (performanceReader.Read())
                    {
                        theatre.Addperformance((int)performanceReader[0], (string)performanceReader[1], (DateTime)performanceReader[2]);


                    }
                    PubConn.Close();
                    
                    
                }
            }
            foreach (Performance p in theatre.GetPerformances())
            {
                performanceTable.Rows.Add(p, p.PerformanceTitle, p.PerformanceDate);

            }

            PerformanceGridView.DataSource = performanceTable;
            PerformanceGridView.Columns[0].Visible = false;
            

        }
        //get the tickets and bookings



        private Ticket FindTicket(Booking booking, int ticketID)
        {
            Ticket newTicket = null;
            using (SqlConnection PubConn = new SqlConnection(connectionString))
            {

                SqlParameter ticketIDParam = new SqlParameter();
                ticketIDParam.Value = ticketID;
                ticketIDParam.ParameterName = "@ticketID";
                using (SqlCommand ticketReaderCommand = new SqlCommand("select * from Tickets where TicketID = @ticketID", PubConn))
                {
                    PubConn.Open();
                    ticketReaderCommand.Parameters.Add(ticketIDParam);
                    SqlDataReader ticketReader = ticketReaderCommand.ExecuteReader();

                    ticketReader.Read();

                    foreach (Customer customer in theatre.CustomerList)
                    {

                        if (customer.CustomerID == (int)ticketReader[1])
                        {

                            newTicket = new Ticket(ticketID, customer, new Seat((int)ticketReader[2]), (double)ticketReader[4], (string)ticketReader[3]);

                        }
                    }


                    PubConn.Close();
                }
            }
            return newTicket;
        }




        private void DisplaySeating(Performance performance)
        {
            
            foreach (PictureBox p in pictureBoxArray)
            {
                p.Image = Image.FromFile(IMAGEPATH + "DefaultSeat" + ".jpg");
            }
            
            for (int i = 0; i < MAXROWS; i++)
            {
                for (int j = 0; j < MAXCOLUMNS; j++)
                {
                    if (performance.SeatingArray[i, j] != null)
                    {
                        if (performance.SeatingArray[i, j].IsBooked)
                        {
                            pictureBoxArray[i, j].Image = Image.FromFile(IMAGEPATH + "BookedSeat" + ".jpg");
                        }

                    }
                    else
                    {
                        pictureBoxArray[i, j].Image = Image.FromFile(IMAGEPATH + "DefaultSeat" + ".jpg");
                    }
                }
            }
            //display Bookings
            performance.BookingList.Clear();

            using (SqlConnection PubConn = new SqlConnection(connectionString))
            {

                using (SqlCommand bookingReaderCommand = new SqlCommand("SELECT * FROM Bookings", PubConn))
                {
                    PubConn.Open();
                    SqlDataReader bookingReader = bookingReaderCommand.ExecuteReader();

                    while (bookingReader.Read())
                    {
                        foreach (Performance p in theatre.GetPerformances())
                        {
                            if (p.PerformanceNumber == (int)bookingReader[2])
                            {
                                bool isFound = false;
                                foreach (Booking booking in p.BookingList)
                                {
                                    if (booking.BookingID == (int)bookingReader[0])
                                    {
                                        isFound = true;
                                        int ticketID = (int)bookingReader[1];
                                        Ticket ticket = FindTicket(booking, ticketID);
                                        PictureBox seatBox = pictureBoxArray[((ticket.Seat.SeatNumber / 18)), ((ticket.Seat.SeatNumber % 18))];
                                        
                                        if (p.SeatingArray[(ticket.Seat.SeatNumber) / 18, (ticket.Seat.SeatNumber) % 18] == null)
                                        {
                                            p.SeatingArray[(ticket.Seat.SeatNumber) / 18, (ticket.Seat.SeatNumber) % 18] = ticket.Seat;

                                            p.SeatingArray[(ticket.Seat.SeatNumber) / 18, (ticket.Seat.SeatNumber) % 18].Book();
                                            seatBox.Tag = $"\n{ticket.Customer.Forename} {ticket.Customer.Surname}\n£{ticket.PricePaid}";
                                            seatBox.Image = Image.FromFile(IMAGEPATH + "BookedSeat" + ".jpg");
                                        }
                                        else
                                        {

                                            p.SeatingArray[(ticket.Seat.SeatNumber) / 18, (ticket.Seat.SeatNumber) % 18].Book();
                                            seatBox.Tag = $"\n{ticket.Customer.Forename} {ticket.Customer.Surname}\n£{ticket.PricePaid}";
                                            seatBox.Image = Image.FromFile(IMAGEPATH + "BookedSeat" + ".jpg");
                                        }
                                        booking.AddTicket(ticket);
                                        ToolTip toolTip1 = new ToolTip();
                                        toolTip1.SetToolTip(seatBox, $"{(int.Parse(seatBox.Name) / 18) + 1},{(int.Parse(seatBox.Name) % 18) + 1}{seatBox.Tag}");
                                    }

                                }
                                if (!isFound)
                                {
                                    Booking newBooking = new Booking((int)bookingReader[0], performance);
                                    performance.BookingList.Add(newBooking);
                                    int ticketID = (int)bookingReader[1];
                                    Ticket ticket = FindTicket(newBooking, ticketID);
                                    PictureBox seatBox = pictureBoxArray[(ticket.Seat.SeatNumber) / 18, (ticket.Seat.SeatNumber) % 18];
                                    
                                    if (p.SeatingArray[(ticket.Seat.SeatNumber) / 18, (ticket.Seat.SeatNumber) % 18] == null)
                                    {
                                        p.SeatingArray[(ticket.Seat.SeatNumber) / 18, (ticket.Seat.SeatNumber) % 18] = ticket.Seat;
                                        p.SeatingArray[(ticket.Seat.SeatNumber) / 18, (ticket.Seat.SeatNumber) % 18].Book();
                                        
                                        seatBox.Tag = $"\n{ticket.Customer.Forename} {ticket.Customer.Surname}\n£{ticket.PricePaid}";
                                        seatBox.Image = Image.FromFile(IMAGEPATH + "BookedSeat" + ".jpg");

                                    }
                                    else
                                    {
                                        performance.SeatingArray[(ticket.Seat.SeatNumber) / 18, (ticket.Seat.SeatNumber) % 18].Book();

                                        seatBox.Tag = $"\n{ticket.Customer.Forename} {ticket.Customer.Surname}\n£{ticket.PricePaid}";
                                        seatBox.Image = Image.FromFile(IMAGEPATH + "BookedSeat" + ".jpg");
                                    }
                                    ToolTip toolTip1 = new ToolTip();
                                    toolTip1.SetToolTip(seatBox, $"{(int.Parse(seatBox.Name) / 18) + 1},{(int.Parse(seatBox.Name) % 18) + 1}{seatBox.Tag}");
                                    newBooking.AddTicket(ticket);


                                }
                            }
                        }

                    }
                    PubConn.Close();
                }
            }
            DataTable bookingsTable = new DataTable();
            bookingsTable.Columns.Add("Booking", typeof(Booking));
       
            bookingsTable.Columns.Add("Total price", typeof(decimal));
            bookingsTable.Columns.Add("Total tickets", typeof(int));
            foreach (Booking booking in performance.BookingList)
            {
                bookingsTable.Rows.Add(booking, booking.TotalPrice, booking.TotalTickets);
            }
            bookingGridView.DataSource = bookingsTable;
            bookingGridView.Columns[0].Visible = false;

            //display Blockings
            using (SqlConnection PubConn = new SqlConnection(connectionString))
            {
                SqlParameter PerformanceNumberParam = new SqlParameter("@PerformanceNumber", performance.PerformanceNumber);
                using (SqlCommand blockReaderCommand = new SqlCommand("SELECT * FROM Blockings WHERE PerformanceNumber = @PerformanceNumber", PubConn))
                {
                    PubConn.Open();

                    performance.BlockedSeats.Clear();
                    blockReaderCommand.Parameters.Add(PerformanceNumberParam);
                    SqlDataReader blockReader = blockReaderCommand.ExecuteReader();
                    while (blockReader.Read())
                    {
                        int seatNumber = (int)blockReader[0];
                        if (performance.SeatingArray[(seatNumber) / 18, (seatNumber) % 18] != null)
                        {

                            pictureBoxArray[(seatNumber) / 18, (seatNumber) % 18].Image = Image.FromFile(IMAGEPATH + "BlockedSeat" + ".jpg");
                            performance.BlockedSeats.Add(performance.SeatingArray[(seatNumber / 18), (seatNumber % 18)]);
                            performance.SeatingArray[(seatNumber ) / 18, (seatNumber) % 18].Block();

                        }
                        else
                        {
                            Seat newSeat = new Seat(seatNumber);
                            newSeat.Block();
                            pictureBoxArray[(seatNumber) / 18, (seatNumber) % 18].Image = Image.FromFile(IMAGEPATH + "BlockedSeat" + ".jpg");
                            performance.SeatingArray[(seatNumber) / 18, (seatNumber) % 18] = newSeat;
                            performance.BlockedSeats.Add(newSeat);
                        }
                    }

                    PubConn.Close();
                }
            }
        }

        

        private void SeatSelected(object sender, EventArgs e)
        {
            PictureBox seatBox = (PictureBox)sender;
            Seat selectedSeat = selectedPerformance.SeatingArray[int.Parse(seatBox.Name) / 18, int.Parse(seatBox.Name) % 18];
            if (selectedSeat != null)
            {
                bool selected = false ;
                Seat seatToRemove = null;
                foreach(Seat seat in selectedSeats)
                {
                    if(selectedSeat.SeatNumber == seat.SeatNumber)
                    {
                        selected = true;
                        if (selectedSeat.IsBooked)
                        {

                            seatToRemove = seat;
                            seatBox.Image = Image.FromFile(IMAGEPATH + "BookedSeat" + ".jpg");
                            userSelectedSeats--;
                        }
                        else if(selectedSeat.IsBlocked)
                        {
                            seatToRemove = seat;
                            seatBox.Image = Image.FromFile(IMAGEPATH + "BlockedSeat" + ".jpg");
                            userSelectedSeats--;
                        }
                        else
                        {
                            seatToRemove = seat;
                            seatBox.Image = Image.FromFile(IMAGEPATH + "DefaultSeat" + ".jpg");
                            userSelectedSeats--;
                            
                        }
                    }
                }
                  
                    
                if(!selected)
                {
                    selectedSeats.Add(selectedSeat);
                        
                    seatBox.Image = Image.FromFile(IMAGEPATH + "SelectedSeat" + ".jpg");
                    userSelectedSeats++;
                }
                else
                {
                    selectedSeats.Remove(seatToRemove);
                }

                
            }
            else
            {
                selectedSeat = new Seat(int.Parse(seatBox.Name ));
                userSelectedSeats++;
                selectedPerformance.SeatingArray[int.Parse(seatBox.Name) / 18, int.Parse(seatBox.Name) % 18] = selectedSeat;
                selectedSeats.Add(selectedSeat);
                seatBox.Image = Image.FromFile(IMAGEPATH + "SelectedSeat" + ".jpg");
            }



        }

        

        private void PerformanceGridView_RowEnter(object sender, DataGridViewCellEventArgs e)
        {
            Performance p = ((Performance)PerformanceGridView.Rows[e.RowIndex].Cells[0].Value);

            DisplaySeating(p);
            
            
            selectedSeats = new List<Seat>();
            selectedPerformance = p;

        }
        


        

     

        private void BookingGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void addBooking_Click(object sender, EventArgs e)
        {
            if (!(selectedSeats.Count == 0))
            {
                bool seatIsBooked = false;
                bool seatNotBlocked = true;
                foreach(Seat seat in selectedSeats)
                {
                    if(seat.IsBooked)
                    {
                        seatIsBooked = true;
                    }
                    if(seat.IsBlocked)
                    {
                        seatNotBlocked = false;
                    }
                }
                
                if(userSelectedSeats == selectedSeats.Count && !seatIsBooked && seatNotBlocked)
                {
                    if (!CheckIfBookingLeavesSeat(selectedPerformance))
                    {
                        BookingForm newBooking = new BookingForm(selectedSeats, (Performance)PerformanceGridView.SelectedRows[0].Cells[0].Value);

                        newBooking.ShowDialog();

                        selectedSeats.Clear();
                        userSelectedSeats = 0;
                        DisplaySeating(selectedPerformance);
                    }
                    else
                    {
                        LeaveSeatWarningFrm newWarningFrm = new LeaveSeatWarningFrm(selectedSeats, (Performance)PerformanceGridView.SelectedRows[0].Cells[0].Value);
                        newWarningFrm.ShowDialog();
                        selectedSeats.Clear();
                        userSelectedSeats = 0;
                        DisplaySeating(selectedPerformance);
                    }
                    
                }
                else if(!seatIsBooked)
                {
                    MessageBox.Show("Error, some of the selected seats are already booked, is a booking selected?");
                }
                else
                {
                    MessageBox.Show("Error, some of the selected seats are blocked");
                }
                


            }
            else
            {
                MessageBox.Show("Error, no seats selected");
            }


        }

        private void bookingGridView_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            
            DataGridView selectedRow = (DataGridView)sender;
            Booking selectedBooking = (Booking)selectedRow.SelectedRows[0].Cells[0].Value;
            bool isAlreadySelected = false;
            foreach(Ticket ticket in selectedBooking.TicketList)
            {
                if(selectedSeats.Contains(ticket.Seat))
                {
                    isAlreadySelected = true;
                }
            }
            if (!isAlreadySelected)
            {
                if (selectedSeats.Count == 0)
                {
                    foreach (Ticket ticket in selectedBooking.TicketList)
                    {
                        selectedSeats.Add(ticket.Seat);
                        pictureBoxArray[(ticket.Seat.SeatNumber) / 18, (ticket.Seat.SeatNumber) % 18].Image = Image.FromFile(IMAGEPATH + "SelectedSeat" + ".jpg");
                    }
                }
                else
                {
                   
                    foreach (PictureBox pictureBox in pictureBoxArray)
                    {
                        pictureBox.Image = Image.FromFile(IMAGEPATH + "DefaultSeat" + ".jpg");
                    }
                    foreach (Booking booking in selectedPerformance.BookingList)
                    {
                        foreach (Ticket ticket in booking.TicketList)
                        {
                            pictureBoxArray[(ticket.Seat.SeatNumber) / 18, (ticket.Seat.SeatNumber) % 18].Image = Image.FromFile(IMAGEPATH + "BookedSeat" + ".jpg");
                        }
                    }
                    selectedSeats.Clear();

                    foreach (Ticket ticket in selectedBooking.TicketList)
                    {

                        selectedSeats.Add(ticket.Seat);
                        pictureBoxArray[(ticket.Seat.SeatNumber ) / 18, (ticket.Seat.SeatNumber) % 18].Image = Image.FromFile(IMAGEPATH + "SelectedSeat" + ".jpg");
                    }


                }
            }
            else
            {
                selectedSeats.Clear();
                userSelectedSeats = 0;
                DisplaySeating(selectedPerformance);
            }

        }

        private void bookingGridView_RowEnter(object sender, DataGridViewCellEventArgs e)
        {
            
        }
        public bool CheckIfBookingLeavesSeat(Performance performance)
        {
            bool leavesSeat = false;
            for(int i = 0; i < 11; i++)
            {
                int seatsBookedOrBlocked = 0;
                for(int j = 0; j < 18; j++)
                {
                    if (performance.SeatingArray[i, j] != null)
                    {
                        if (performance.SeatingArray[i, j].IsBooked)
                        {
                            seatsBookedOrBlocked++;
                        }
                        else if (performance.SeatingArray[i, j].IsBlocked)
                        {
                            seatsBookedOrBlocked++;
                        }
                    }
                }
                if ((18 - seatsBookedOrBlocked) <= selectedSeats.Count)
                {
                    leavesSeat = true;
                }
            }
            return leavesSeat;
        }
        private void EditBooking_Click(object sender, EventArgs e)
        {
            Booking selectedBooking = (Booking)bookingGridView.SelectedRows[0].Cells[0].Value;
            if (selectedSeats.Count == 0)
            {
                MessageBox.Show("error no seats or bookings have been selected");
            }
            else
            {


                bool selectedSeatsAreValid = true;
                bool selectedSeatsNotBlocked = true;
                foreach (Seat seat in selectedSeats)
                {
                    bool found = false;
                    foreach (Ticket ticket in selectedBooking.TicketList)
                    {
                        if (ticket.Seat == seat)
                        {
                            found = true;
                        }
                    }
                    if (found == false && seat.IsBooked)
                    {
                        selectedSeatsAreValid = false;
                    }
                    if(seat.IsBlocked)
                    {
                        selectedSeatsNotBlocked = false;
                    }
                }
                if (selectedSeatsAreValid && selectedSeatsNotBlocked)
                {
                    
                    if (!CheckIfBookingLeavesSeat(selectedPerformance))
                    {
                        BookingForm edittedBookingFrm = new BookingForm(selectedBooking, selectedSeats, selectedPerformance);
                        edittedBookingFrm.ShowDialog();
                        selectedSeats.Clear();
                        userSelectedSeats = 0;
                        DisplaySeating(selectedPerformance);
                    }
                    else
                    {
                        LeaveSeatWarningFrm newWarningFrm = new LeaveSeatWarningFrm(selectedSeats, selectedBooking, selectedPerformance);
                        newWarningFrm.ShowDialog();
                        selectedSeats.Clear();
                        userSelectedSeats = 0;
                        DisplaySeating(selectedPerformance);
                    }
                   
                }
                else if(!selectedSeatsAreValid)
                {
                    MessageBox.Show("Error, some of the selected seats are from different bookings");
                }
                else
                {
                    MessageBox.Show("Error, some of the selected seats are blocked");
                }
            }
            
        }

        private void DeleteBookingClick(object sender, EventArgs e)
        {
            Booking booking = (Booking)bookingGridView.SelectedRows[0].Cells[0].Value;
            
            foreach (Ticket ticket in booking.TicketList)
            {
                ticket.removeDB();
                ticket.Seat.UnBook();
            }
            booking.RemoveDB();
           
            selectedSeats.Clear();
            DisplaySeating(selectedPerformance);
          
            bookingGridView.Rows.Remove(bookingGridView.SelectedRows[0]);
            bookingGridView.Refresh();
        }

        private void AddPerformanceButton_Click(object sender, EventArgs e)
        {
            
            PerformanceDetailsFrm newPerformanceFrm = new PerformanceDetailsFrm();
            newPerformanceFrm.ShowDialog();
            GetPerformances();
            
        }

        private void EditPerformanceButton_Click(object sender, EventArgs e)
        {
            PerformanceDetailsFrm editPerformanceFrm = new PerformanceDetailsFrm(selectedPerformance);
            editPerformanceFrm.ShowDialog();
            GetPerformances();
        }

        private void DeletePerformanceButton_Click(object sender, EventArgs e)
        {
            Performance performance = (Performance)PerformanceGridView.SelectedRows[0].Cells[0].Value;

            foreach(Booking booking in performance.BookingList)
            {
                booking.RemoveDB();
                foreach (Ticket ticket in booking.TicketList)
                {
                    ticket.removeDB();
                    ticket.Seat.UnBook();
                }
                
            }
            performance.RemoveDB();
            GetPerformances();
            DisplaySeating(selectedPerformance);
            selectedSeats.Clear();
           
      
           
          
        }

        private void bookSelectedSeatsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            addBooking_Click(sender, e);
        }

        private void editSelectedBookingToolStripMenuItem_Click(object sender, EventArgs e)
        {
            EditBooking_Click(sender, e);
        }

        private void addNewCustomerToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            AddCustomerFrm newCustomerFrm = new AddCustomerFrm();

            newCustomerFrm.ShowDialog();
            
        }

        private void viewTicketListToolStripMenuItem_Click(object sender, EventArgs e)
        {
            TicketForm newTicketForm = new TicketForm(selectedPerformance);
            newTicketForm.ShowDialog();
        }

        private void BlockSeatButton_Click(object sender, EventArgs e)
        {
            bool isValid = true;
            foreach(Seat seat in selectedSeats)
            {
                if(seat.IsBooked)
                {
                    isValid = false;
                }
            }
            if(isValid)
            {
                foreach (Seat seat in selectedSeats)
                {
                    if (seat.IsBlocked)
                    {
                        seat.UnBlock(selectedPerformance.PerformanceNumber);
                        
                    }
                    else
                    {
                        seat.Block(selectedPerformance.PerformanceNumber);
                        
                    }
                }
                selectedSeats.Clear();
                DisplaySeating(selectedPerformance);
                
            }
            else
            {
                MessageBox.Show("Error, one of the selected seats is Booked");
            }
        }

        private void blockunblockSelectedSeatsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            BlockSeatButton_Click(sender, e);
        }

        private void searchCustomersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CustomerFrm newCustomerFrm = new CustomerFrm();

            newCustomerFrm.ShowDialog();
            
        }
    }
}
